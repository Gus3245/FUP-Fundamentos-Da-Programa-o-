num = int(input(""))
total = 1

for i in range(num):
    for c in range(i + 1):
        print(total, end=" ")
        total = total + 1
    print()
    
        
        
