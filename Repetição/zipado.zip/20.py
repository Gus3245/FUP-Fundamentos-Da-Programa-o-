def funcao(x):
    for i in range(1 , x + 1):
        print("*" * i)
    for c in range(x-1, 0, -1):
        print("*" * c)
