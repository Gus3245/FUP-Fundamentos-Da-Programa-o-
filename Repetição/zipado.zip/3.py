soma = 0

for i in range(1, 11):
    numero = float(input(""))
    soma = soma + numero

print(f"{soma:.2f}")
