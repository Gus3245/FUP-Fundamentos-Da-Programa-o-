soma = 0

for i in range(1, 11):
    numero = float(input(""))
    soma = soma + numero
    
soma = soma/10

print(f"{soma:.2f}")
