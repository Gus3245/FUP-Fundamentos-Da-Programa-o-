def funcao(x1,x2):
    for i in range(1, 2):
        y = x1**x2
    
    return y
