str1 = input()
for i in str1:
    Convert = chr(ord(i) + 1)
    print(Convert, end="")
