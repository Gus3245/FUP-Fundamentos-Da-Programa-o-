num = 0
for i in range(1 , 10):
    for c in range(0, 10):
        print(f"{i} + {num} =", i + num)
        num += 1
    num = 0
        
