def funcao(x):
    y = 0
    for i in range(0,(x*2), 2):
        y = y + i
        
    return y
