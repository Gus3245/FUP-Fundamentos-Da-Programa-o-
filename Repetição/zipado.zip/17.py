total = int(input(""))

for i in range(1 , total + 1):
    print("=", end="")
