def funcao(x):
    for x in range(1 , x+1):
        print("!" * x)
        
        
