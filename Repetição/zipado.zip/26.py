from math import factorial

def funcao(x1, x2):
    resultado = 0
    
    for i in range(x2+1):
        resultado += ((-1)**i)*(x1**(2*i+1))/(factorial(2*i+1))
    return resultado
