num = int(input())

for i in range(0, num):
    print("Estou sabendo Programar haha")
