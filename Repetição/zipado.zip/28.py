for i in range(0, 10):
    print("Meu Curso eh Show")
