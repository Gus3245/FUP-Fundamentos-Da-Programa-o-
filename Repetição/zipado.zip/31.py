str1 = input()
str2 = input()
N = int(input())

print(str1, end="")
for i in range(N):
    print(str2, end="")
