n = int(input(""))
soma = 0

for i in range(1, n+1):
    soma = soma + i

print(soma)
