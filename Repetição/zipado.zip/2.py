for i in range(0, 100001, 1000):
    print(i)
