from math import factorial

def funcao(x):
    for i in range(10):
        fator = factorial(x)
    
    return fator
        
    
        
