for i in range(1, 101):
    print(i)

