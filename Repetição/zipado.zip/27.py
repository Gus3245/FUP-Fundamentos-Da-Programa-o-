def funcao(x):
    fatoria = 1
    
    for i in range(1, x+1):
        fatoria = i ** fatoria
    return fatoria
