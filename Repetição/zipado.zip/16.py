soma = 0
num = 1

for i in range(1 , 51):
    soma = soma + num / i
    num = num + 2
    

print(f"{soma:.10f}")
        
        
