
def funcao(x):
    y = 0
    for i in range(1 , x+1):
        y = y + i
    
    
    return y
