nome = input()
print(nome[::-1])
